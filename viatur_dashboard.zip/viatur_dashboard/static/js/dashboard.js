/* ─────────────────────────────────────────────────────────
   Jundiá.NET — Painel Operacional
   dashboard.js  |  lógica completa do frontend
   ───────────────────────────────────────────────────────── */

const Charts = {};

// ─── Navegação ────────────────────────────────────────────
const PAGE_TITLES = {
  inicio:      "Início — visão geral",
  frota:       "Frota — tempo real",
  rotas:       "Rotas & destinos",
  combustivel: "Combustível",
  manutencao:  "Manutenção",
  financeiro:  "Financeiro",
  motoristas:  "Motoristas",
};

function navTo(el) {
  document.querySelectorAll(".nav-item").forEach(x => x.classList.remove("active"));
  el.classList.add("active");
  const page = el.dataset.page;
  document.querySelectorAll(".page").forEach(x => x.classList.remove("active"));
  document.getElementById("page-" + page).classList.add("active");
  document.getElementById("page-title").textContent = PAGE_TITLES[page];
}

// ─── Formatação ───────────────────────────────────────────
const fmt    = (n, pre="", suf="") => n == null ? "—" : pre + Number(n).toLocaleString("pt-BR") + suf;
const fmtR   = n => n == null ? "—" : "R$" + (n/1000).toFixed(1) + "k";
const fmtM   = n => "R$" + (n/1_000_000).toFixed(2) + "M";
const iniciais = nome => nome.split(" ").map(x => x[0]).slice(0,2).join("");

// ─── Relógio ──────────────────────────────────────────────
function iniciarRelogio() {
  setInterval(() => {
    document.getElementById("clock").textContent = new Date().toLocaleTimeString("pt-BR");
  }, 1000);
}

// ─── Helpers de gráfico ───────────────────────────────────
const CORES = ["#1D3557","#1B6CA8","#2D6A4F","#B5530A","#E63946","#5C8374","#7D6B91","#C47F5A"];

function barChart(id, labels, data, labelY = "") {
  if (Charts[id]) Charts[id].destroy();
  Charts[id] = new Chart(document.getElementById(id), {
    type: "bar",
    data: { labels, datasets: [{ data, backgroundColor: "#1D3557", borderRadius: 5, barPercentage: 0.7 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { grid: { color: "#f0f0ec" }, ticks: { font: { size: 11 }, callback: v => labelY ? labelY(v) : v } },
        x: { grid: { display: false }, ticks: { font: { size: 11 } } },
      },
    },
  });
}

function hBarChart(id, labels, data, color="#1D3557") {
  if (Charts[id]) Charts[id].destroy();
  Charts[id] = new Chart(document.getElementById(id), {
    type: "bar",
    data: { labels, datasets: [{ data, backgroundColor: color, borderRadius: 4, barPercentage: 0.6 }] },
    options: {
      indexAxis: "y",
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: "#f0f0ec" }, ticks: { font: { size: 10 } } },
        y: { grid: { display: false }, ticks: { font: { size: 11 } } },
      },
    },
  });
}

function doughnutChart(id, labels, data) {
  if (Charts[id]) Charts[id].destroy();
  Charts[id] = new Chart(document.getElementById(id), {
    type: "doughnut",
    data: { labels, datasets: [{ data, backgroundColor: CORES, borderWidth: 0 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: "bottom", labels: { font: { size: 11 }, boxWidth: 10 } } },
    },
  });
}

// ─── KPIs ─────────────────────────────────────────────────
async function loadKPIs() {
  const d = await fetch("/api/kpis").then(r => r.json());
  document.getElementById("k-viagens").textContent  = d.viagens_hoje;
  document.getElementById("k-pass").textContent     = fmt(d.passageiros_hoje);
  document.getElementById("k-receita").textContent  = fmtR(d.receita_hoje);
  document.getElementById("k-ocup").textContent     = d.ocupacao_media + "%";
  document.getElementById("k-km").textContent       = fmt(d.km_rodados_hoje);
  document.getElementById("k-emrota").textContent   = d.onibus_em_rota;
  document.getElementById("k-nps").textContent      = d.nps;
  document.getElementById("k-alertas").textContent  = d.alertas_ativos;
  document.getElementById("fin-hoje").textContent   = fmtR(d.receita_hoje);
}

// ─── Receita ──────────────────────────────────────────────
async function loadReceita() {
  const data = await fetch("/api/receita-mensal").then(r => r.json());
  const totalAno = data.reduce((s,d) => s+d.receita, 0);
  const mesMaior = data.reduce((mx,d) => d.receita>mx.receita?d:mx, data[0]);
  document.getElementById("fin-ano").textContent = fmtM(totalAno);
  document.getElementById("fin-mes").textContent = fmtR(mesMaior.receita);

  const meses    = data.map(d => d.mes);
  const receitas = data.map(d => Math.round(d.receita/1000));
  const cfg = v => "R$"+v+"k";
  ["chart-receita","chart-fin"].forEach(id => barChart(id, meses, receitas, cfg));
}

// ─── Rotas ────────────────────────────────────────────────
async function loadRotas() {
  const data = await fetch("/api/ocupacao-rotas").then(r => r.json());

  document.getElementById("rotas-bars-inicio").innerHTML = data.map(r => `
    <div class="rota-row">
      <div class="rota-info">
        <span class="rota-name">${r.rota.replace("Rio → ","")}</span>
        <span class="rota-pct">${r.ocupacao.toFixed(0)}%</span>
      </div>
      <div class="rota-bar"><div class="rota-fill" style="width:${r.ocupacao}%"></div></div>
    </div>`).join("");

  document.getElementById("rotas-tbody").innerHTML = data.map(r => `
    <tr>
      <td>${r.rota}</td>
      <td><div class="fuel-bar-wrap"><div class="fuel-bar"><div class="fuel-fill fuel-ok" style="width:${r.ocupacao}%"></div></div>${r.ocupacao.toFixed(0)}%</div></td>
      <td>${r.viagens_mes}</td>
      <td>${fmtR(r.receita_mes)}</td>
      <td>R$ ${r.preco_medio}</td>
    </tr>`).join("");

  const nomes = data.map(d => d.rota.replace("Rio → ",""));
  doughnutChart("chart-rotas-viagens", nomes, data.map(d => d.viagens_mes));
  doughnutChart("chart-rotas-receita", nomes, data.map(d => d.receita_mes));
}

// ─── Alertas ──────────────────────────────────────────────
async function loadAlertas() {
  const alertas = await fetch("/api/manutencao").then(r => r.json());
  const html = alertas.map(a => `
    <div class="alerta-card">
      <div class="alerta-icon ${a.prioridade==="alta"?"icon-alta":"icon-media"}">
        <i class="ti ti-${a.prioridade==="alta"?"alert-circle":"alert-triangle"}"></i>
      </div>
      <div>
        <div class="alerta-title">${a.bus} — ${a.tipo}</div>
        <div class="alerta-sub">${a.dias<0?Math.abs(a.dias)+"d vencido":"em "+a.dias+"d"} · prioridade ${a.prioridade}</div>
      </div>
    </div>`).join("");
  document.getElementById("alertas-home").innerHTML  = html;
  document.getElementById("alertas-manut").innerHTML = html;
}

// ─── Motoristas ───────────────────────────────────────────
async function loadMotoristas() {
  const data = await fetch("/api/motoristas").then(r => r.json());
  document.getElementById("motoristas-list").innerHTML = data.map(m => {
    const cls = m.cnh_vence<=10?"cnh-crit":m.cnh_vence<=30?"cnh-warn":"cnh-ok";
    return `
      <div class="motorista-row">
        <div class="m-avatar">${iniciais(m.nome)}</div>
        <div><div class="m-name">${m.nome}</div><div class="m-sub">${m.viagens} viagens realizadas</div></div>
        <div class="m-right">
          <div class="m-nota">★ ${m.nota}</div>
          <div class="m-cnh ${cls}">CNH vence em ${m.cnh_vence}d</div>
        </div>
      </div>`;
  }).join("");
}

// ─── COMBUSTÍVEL — dados do CSV ───────────────────────────
async function loadCombustivel() {
  const [mensal, porOnibus] = await Promise.all([
    fetch("/api/combustivel/mensal").then(r => r.json()),
    fetch("/api/combustivel/por-onibus").then(r => r.json()),
  ]);

  // KPIs
  const totalL    = mensal.reduce((s,d) => s+d.litros, 0);
  const totalCusto= mensal.reduce((s,d) => s+d.custo, 0);
  const totalKm   = mensal.reduce((s,d) => s+d.km, 0);
  const kmlMedio  = totalL > 0 ? (totalKm/totalL).toFixed(2) : "—";
  const precoMedio= (totalCusto/totalL).toFixed(3);

  document.getElementById("c-litros").textContent = fmt(Math.round(totalL));
  document.getElementById("c-custo").textContent  = fmtM(totalCusto);
  document.getElementById("c-kml").textContent    = kmlMedio+" km/L";
  document.getElementById("c-preco").textContent  = "R$"+precoMedio;

  // Gráficos
  const meses = mensal.map(d => d.mes);
  barChart("chart-comb-mensal", meses, mensal.map(d => Math.round(d.litros)));
  barChart("chart-comb-custo",  meses, mensal.map(d => Math.round(d.custo)), v => "R$"+v.toLocaleString("pt-BR"));

  // Tabela eficiência
  const kmlMax = Math.max(...porOnibus.map(b => b.kml));
  document.getElementById("comb-tbody").innerHTML = porOnibus.map(b => {
    const pct   = Math.round((b.kml/kmlMax)*100);
    const cls   = b.kml >= kmlMax*0.9 ? "fuel-ok" : b.kml >= kmlMax*0.75 ? "fuel-mid" : "fuel-low";
    return `
      <tr>
        <td><strong>${b.id}</strong></td>
        <td>${b.modelo}</td>
        <td>${b.ano_fab}</td>
        <td>${fmt(b.km_total)} km</td>
        <td>${fmt(Math.round(b.litros))} L</td>
        <td>R$ ${fmt(Math.round(b.custo))}</td>
        <td><span style="font-family:'DM Mono',monospace">R$${b.custo_km}/km</span></td>
        <td>
          <div class="fuel-bar-wrap">
            <div class="fuel-bar"><div class="fuel-fill ${cls}" style="width:${pct}%"></div></div>
            <span style="font-size:11px;font-family:'DM Mono',monospace">${b.kml} km/L</span>
          </div>
        </td>
      </tr>`;
  }).join("");
}

// ─── MANUTENÇÃO — dados do CSV ────────────────────────────
async function loadManutencao() {
  const [historico, porTipo] = await Promise.all([
    fetch("/api/manutencao/historico").then(r => r.json()),
    fetch("/api/manutencao/custo-tipo").then(r => r.json()),
  ]);

  // Gráficos
  const tipos  = porTipo.map(d => d.tipo);
  const custos = porTipo.map(d => d.custo_total);
  const horas  = porTipo.map(d => d.horas_total);
  hBarChart("chart-manut-tipo",  tipos, custos, "#1D3557");
  hBarChart("chart-manut-horas", tipos, horas,  "#B5530A");

  // Tabela histórico
  const catCls = c => c==="Corretiva" ? "s-manut" : "s-garagem";
  document.getElementById("manut-historico-tbody").innerHTML = historico.map(r => `
    <tr>
      <td><strong>${r.bus}</strong><br><span style="font-size:10px;color:var(--muted)">${r.placa}</span></td>
      <td>${r.data}</td>
      <td>${fmt(r.km)} km</td>
      <td>${r.tipo}</td>
      <td><span class="status-badge ${catCls(r.categoria)}">${r.categoria}</span></td>
      <td>R$ ${fmt(Math.round(r.custo))}</td>
      <td>${r.horas}h</td>
      <td>${r.tecnico}</td>
    </tr>`).join("");
}

// ─── Frota SSE ────────────────────────────────────────────
function renderFrota(data) {
  const STATUS = {
    "Em rota":    { cls:"s-rota",    icon:"ti-circle-check" },
    "Na garagem": { cls:"s-garagem", icon:"ti-parking"      },
    "Manutenção": { cls:"s-manut",   icon:"ti-tool"         },
  };
  document.getElementById("f-rota").textContent    = data.filter(b=>b.status==="Em rota").length;
  document.getElementById("f-garagem").textContent = data.filter(b=>b.status==="Na garagem").length;
  document.getElementById("f-manut").textContent   = data.filter(b=>b.status==="Manutenção").length;
  document.getElementById("f-pax").textContent     = data.reduce((s,b)=>s+b.passageiros_bordo,0);

  document.getElementById("frota-tbody").innerHTML = data.map(b => {
    const st = STATUS[b.status];
    const fc = b.combustivel<25?"fuel-low":b.combustivel<50?"fuel-mid":"fuel-ok";
    return `
      <tr>
        <td><strong>${b.id}</strong><br><span style="font-size:10px;color:var(--muted)">${b.placa}</span></td>
        <td>${b.modelo}<br><span style="font-size:10px;color:var(--muted)">${b.ano}</span></td>
        <td><span class="status-badge ${st.cls}"><i class="ti ${st.icon}"></i>${b.status}</span></td>
        <td>${b.rota}</td>
        <td>${b.motorista}</td>
        <td><span style="font-family:'DM Mono',monospace">${b.velocidade>0?b.velocidade+" km/h":"—"}</span></td>
        <td>${b.passageiros_bordo>0?b.passageiros_bordo+"/"+b.capacidade:"—"}</td>
        <td>
          <div class="fuel-bar-wrap">
            <div class="fuel-bar"><div class="fuel-fill ${fc}" style="width:${b.combustivel}%"></div></div>
            <span style="font-size:11px;font-family:'DM Mono',monospace">${b.combustivel}%</span>
          </div>
        </td>
      </tr>`;
  }).join("");
}

function conectarSSE() {
  const es = new EventSource("/stream/frota");
  es.onmessage = e => renderFrota(JSON.parse(e.data));
  es.onerror   = () => { es.close(); setTimeout(conectarSSE, 5000); };
}

// ─── Recarga manual ───────────────────────────────────────
function recarregarTudo() {
  loadKPIs(); loadReceita(); loadRotas(); loadAlertas();
  loadMotoristas(); loadCombustivel(); loadManutencao();
}

// ─── Bootstrap ────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  iniciarRelogio();
  loadKPIs();
  loadReceita();
  loadRotas();
  loadAlertas();
  loadMotoristas();
  loadCombustivel();
  loadManutencao();
  conectarSSE();
  setInterval(loadKPIs, 30_000);
});
