# ViaTur — Painel Operacional (Demo)

Dashboard de demonstração para apresentação interna.  
Dados simulados — sem dependência de banco de dados.

## Requisitos
- Python 3.9+

## Como rodar

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Iniciar o servidor
python app.py
```

Acesse: http://localhost:5001

## Módulos disponíveis

| Módulo        | Descrição                                      | Atualização         |
|---------------|------------------------------------------------|---------------------|
| Início        | KPIs do dia + receita mensal + alertas         | Polling 30s         |
| Frota ao vivo | Status de cada ônibus, velocidade, combustível | SSE streaming (6s)  |
| Rotas         | Ocupação e receita por destino                 | Ao carregar         |
| Manutenção    | Alertas de revisão, km restantes               | Ao carregar         |
| Financeiro    | Receita diária, mensal, anual                  | Polling 30s         |
| Motoristas    | Avaliação, CNH, viagens realizadas             | Ao carregar         |

## Adaptação para Oracle/Globus

Substitua as funções `gerar_*` em `app.py` por consultas reais:

```python
import oracledb  # pip install oracledb

conn = oracledb.connect(user="user", password="pwd", dsn="host:1521/GLOBUS")

def gerar_kpis():
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM VW_VIAGENS WHERE DT_VIAGEM = TRUNC(SYSDATE)")
    ...
```
