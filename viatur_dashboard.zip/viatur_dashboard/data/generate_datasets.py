"""
Gera dois CSVs com estrutura fiel aos datasets públicos referenciados:

1. fuel_consumption.csv
   Baseado em: "Fleet Vehicles Fuel Consumption" (Data Mill North, CC-BY)
   Colunas originais: Fleet, Vehicle_Description, Fuel_Type, Year, Quantity_Litres, Cost_GBP
   Adaptado para R$ e frota de ônibus turístico brasileira.

2. vehicle_maintenance.csv
   Baseado em: "Logistics Vehicle Maintenance History Dataset" (Kaggle)
   Colunas originais: vehicle_id, date, mileage, maintenance_type, cost, downtime_hours, technician
   Mantém estrutura idêntica.
"""

import csv
import random
from datetime import date, timedelta

random.seed(2024)

ONIBUS = [
    {"id": "BUS-01", "placa": "RIO-1A23", "modelo": "Mercedes O-500 RSD", "ano_fab": 2019, "capacidade": 46},
    {"id": "BUS-02", "placa": "RIO-2B45", "modelo": "Volvo B340R",         "ano_fab": 2020, "capacidade": 46},
    {"id": "BUS-03", "placa": "RIO-3C67", "modelo": "Scania K360 IB",      "ano_fab": 2021, "capacidade": 50},
    {"id": "BUS-04", "placa": "RIO-4D89", "modelo": "Mercedes O-500 RSD",  "ano_fab": 2018, "capacidade": 46},
    {"id": "BUS-05", "placa": "RIO-5E01", "modelo": "Volvo B340R",         "ano_fab": 2022, "capacidade": 50},
    {"id": "BUS-06", "placa": "RIO-6F23", "modelo": "Scania K360 IB",      "ano_fab": 2020, "capacidade": 46},
    {"id": "BUS-07", "placa": "RIO-7G45", "modelo": "Mercedes O-500 RSD",  "ano_fab": 2017, "capacidade": 46},
    {"id": "BUS-08", "placa": "RIO-8H67", "modelo": "Volvo B340R",         "ano_fab": 2023, "capacidade": 50},
]

ANOS = [2021, 2022, 2023, 2024]

MESES = list(range(1, 13))

ROTAS = [
    {"nome": "Rio → Búzios",         "km": 176},
    {"nome": "Rio → Petrópolis",     "km": 68 },
    {"nome": "Rio → Angra dos Reis", "km": 166},
    {"nome": "Rio → Paraty",         "km": 244},
    {"nome": "Rio → Cabo Frio",      "km": 156},
]

MANUT_TIPOS = [
    ("Troca de óleo",            "Preventiva", 350,   4),
    ("Revisão geral",            "Preventiva", 1200,  8),
    ("Troca de pneu",            "Corretiva",  900,   6),
    ("Freios",                   "Corretiva",  750,   5),
    ("Suspensão",                "Corretiva",  1100,  10),
    ("Sistema elétrico",         "Corretiva",  600,   7),
    ("Ar-condicionado",          "Preventiva", 480,   4),
    ("Filtros e correias",       "Preventiva", 280,   3),
    ("Embreagem",                "Corretiva",  1800,  12),
    ("Injeção eletrônica",       "Corretiva",  950,   8),
]

TECNICOS = ["Carlos Melo", "Ricardo Nunes", "Fabio Dias", "Leandro Costa", "Rodrigo Alves"]


# ─── 1. FUEL CONSUMPTION CSV ──────────────────────────────────────────────────
# Estrutura: Fleet,Vehicle_Description,Fuel_Type,Year,Month,
#            Km_Rodados,Litros_Consumidos,Custo_BRL,Km_por_Litro,Rota_Principal

def gerar_consumo():
    rows = []
    for bus in ONIBUS:
        for ano in ANOS:
            for mes in MESES:
                # Ônibus mais antigos consomem mais
                idade = ano - bus["ano_fab"]
                base_kml = round(random.uniform(3.2, 4.8) - idade * 0.07, 2)
                base_kml = max(2.8, base_kml)

                # Sazonalidade: julho/dezembro/janeiro = mais viagens
                fator_mes = 1.0
                if mes in [1, 7, 12]:
                    fator_mes = 1.35
                elif mes in [6, 11]:
                    fator_mes = 1.15

                km_mes = round(random.uniform(2800, 4200) * fator_mes)
                litros  = round(km_mes / base_kml, 1)
                preco_l = round(random.uniform(5.40, 6.80), 2)  # diesel S10 realista
                custo   = round(litros * preco_l, 2)
                rota    = random.choice(ROTAS)["nome"]

                rows.append({
                    "Fleet":              bus["id"],
                    "Vehicle_Description": bus["modelo"],
                    "Placa":              bus["placa"],
                    "Fuel_Type":          "Diesel S10",
                    "Year":               ano,
                    "Month":              mes,
                    "Km_Rodados":         km_mes,
                    "Litros_Consumidos":  litros,
                    "Preco_Litro_BRL":    preco_l,
                    "Custo_BRL":          custo,
                    "Km_por_Litro":       base_kml,
                    "Rota_Principal":     rota,
                    "Ano_Fabricacao":     bus["ano_fab"],
                })
    return rows


# ─── 2. VEHICLE MAINTENANCE CSV ───────────────────────────────────────────────
# Estrutura: vehicle_id,placa,date,mileage,maintenance_type,category,
#            cost_BRL,downtime_hours,technician,parts_replaced,notes

def gerar_manutencao():
    rows = []
    inicio = date(2021, 1, 1)
    fim    = date(2024, 12, 31)

    for bus in ONIBUS:
        km_acumulado = random.randint(40000, 70000)
        data_atual   = inicio + timedelta(days=random.randint(0, 30))

        while data_atual <= fim:
            tipo, categoria, custo_base, horas_base = random.choice(MANUT_TIPOS)

            km_desde_ultima = random.randint(8000, 18000)
            km_acumulado   += km_desde_ultima

            custo    = round(custo_base * random.uniform(0.85, 1.20), 2)
            horas    = round(horas_base * random.uniform(0.8, 1.3), 1)
            tecnico  = random.choice(TECNICOS)

            pecas = {
                "Troca de óleo":      "Óleo 15W40, filtro de óleo",
                "Revisão geral":      "Filtros, correias, velas",
                "Troca de pneu":      "Pneu 275/80R22.5",
                "Freios":             "Pastilhas e discos dianteiros",
                "Suspensão":          "Amortecedor dianteiro",
                "Sistema elétrico":   "Alternador, fusíveis",
                "Ar-condicionado":    "Filtro cabine, gás R134a",
                "Filtros e correias": "Filtro de ar, correia dentada",
                "Embreagem":          "Kit embreagem completo",
                "Injeção eletrônica": "Bico injetor, sensor MAP",
            }.get(tipo, "Peças diversas")

            rows.append({
                "vehicle_id":       bus["id"],
                "placa":            bus["placa"],
                "modelo":           bus["modelo"],
                "date":             data_atual.isoformat(),
                "mileage":          km_acumulado,
                "maintenance_type": tipo,
                "category":         categoria,
                "cost_BRL":         custo,
                "downtime_hours":   horas,
                "technician":       tecnico,
                "parts_replaced":   pecas,
                "notes":            f"Manutenção {categoria.lower()} — {tipo}",
            })

            # Intervalo realista entre manutenções (45 a 120 dias)
            data_atual += timedelta(days=random.randint(45, 120))

    rows.sort(key=lambda r: (r["vehicle_id"], r["date"]))
    return rows


# ─── Salvar CSVs ──────────────────────────────────────────────────────────────
import os
os.makedirs(os.path.dirname(__file__), exist_ok=True)

BASE = os.path.dirname(__file__)

consumo = gerar_consumo()
with open(f"{BASE}/fuel_consumption.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=consumo[0].keys())
    w.writeheader()
    w.writerows(consumo)
print(f"fuel_consumption.csv  — {len(consumo)} linhas")

manutencao = gerar_manutencao()
with open(f"{BASE}/vehicle_maintenance.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=manutencao[0].keys())
    w.writeheader()
    w.writerows(manutencao)
print(f"vehicle_maintenance.csv — {len(manutencao)} linhas")

# Resumo rápido
import collections
print("\n--- Fuel: consumo médio por ônibus (2024) ---")
totais = collections.defaultdict(lambda: {"km": 0, "litros": 0, "custo": 0, "n": 0})
for r in consumo:
    if r["Year"] == 2024:
        b = r["Fleet"]
        totais[b]["km"]     += r["Km_Rodados"]
        totais[b]["litros"] += r["Litros_Consumidos"]
        totais[b]["custo"]  += r["Custo_BRL"]
        totais[b]["n"]      += 1
for bus, d in sorted(totais.items()):
    kml = round(d["km"] / d["litros"], 2) if d["litros"] else 0
    print(f"  {bus}: {d['km']:,} km | {d['litros']:,.0f} L | R${d['custo']:,.0f} | {kml} km/L")

print("\n--- Manutenção: OS por tipo ---")
por_tipo = collections.Counter(r["maintenance_type"] for r in manutencao)
for tipo, n in por_tipo.most_common():
    custos = [r["cost_BRL"] for r in manutencao if r["maintenance_type"] == tipo]
    media  = round(sum(custos) / len(custos), 2)
    print(f"  {tipo:<25} {n:>3} OS  custo médio R${media:,.0f}")
