from flask import Flask, render_template, jsonify, Response
import json, time, random, math, csv, os
from datetime import datetime, timedelta
from collections import defaultdict

app = Flask(__name__)
random.seed(42)

# ─── Constantes de domínio ────────────────────────────────────────────────────

ONIBUS = [
    {"id": "BUS-01", "placa": "RIO-1A23", "modelo": "Mercedes O-500 RSD", "ano": 2019, "capacidade": 46},
    {"id": "BUS-02", "placa": "RIO-2B45", "modelo": "Volvo B340R",         "ano": 2020, "capacidade": 46},
    {"id": "BUS-03", "placa": "RIO-3C67", "modelo": "Scania K360 IB",      "ano": 2021, "capacidade": 50},
    {"id": "BUS-04", "placa": "RIO-4D89", "modelo": "Mercedes O-500 RSD",  "ano": 2018, "capacidade": 46},
    {"id": "BUS-05", "placa": "RIO-5E01", "modelo": "Volvo B340R",         "ano": 2022, "capacidade": 50},
    {"id": "BUS-06", "placa": "RIO-6F23", "modelo": "Scania K360 IB",      "ano": 2020, "capacidade": 46},
    {"id": "BUS-07", "placa": "RIO-7G45", "modelo": "Mercedes O-500 RSD",  "ano": 2017, "capacidade": 46},
    {"id": "BUS-08", "placa": "RIO-8H67", "modelo": "Volvo B340R",         "ano": 2023, "capacidade": 50},
]

ROTAS = [
    {"nome": "Rio → Búzios",         "km": 176, "duracao_h": 3.0, "preco": 89},
    {"nome": "Rio → Petrópolis",     "km": 68,  "duracao_h": 1.5, "preco": 45},
    {"nome": "Rio → Angra dos Reis", "km": 166, "duracao_h": 2.5, "preco": 79},
    {"nome": "Rio → Paraty",         "km": 244, "duracao_h": 4.0, "preco": 109},
    {"nome": "Rio → Cabo Frio",      "km": 156, "duracao_h": 2.5, "preco": 75},
]

MOTORISTAS = [
    {"nome": "Carlos Souza",   "cnh_vence": 90,  "viagens": 312, "nota": 4.8},
    {"nome": "Marcos Lima",    "cnh_vence": 45,  "viagens": 289, "nota": 4.7},
    {"nome": "João Ferreira",  "cnh_vence": 180, "viagens": 401, "nota": 4.9},
    {"nome": "André Oliveira", "cnh_vence": 12,  "viagens": 198, "nota": 4.6},
    {"nome": "Paulo Santos",   "cnh_vence": 8,   "viagens": 267, "nota": 4.5},
]

# ─── Carga dos CSVs ───────────────────────────────────────────────────────────

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def carregar_csv(nome):
    path = os.path.join(DATA_DIR, nome)
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))

_fuel_raw  = carregar_csv("fuel_consumption.csv")
_manut_raw = carregar_csv("vehicle_maintenance.csv")

# Converte tipos numéricos uma vez
for r in _fuel_raw:
    r["Year"]              = int(r["Year"])
    r["Month"]             = int(r["Month"])
    r["Km_Rodados"]        = int(r["Km_Rodados"])
    r["Litros_Consumidos"] = float(r["Litros_Consumidos"])
    r["Custo_BRL"]         = float(r["Custo_BRL"])
    r["Km_por_Litro"]      = float(r["Km_por_Litro"])
    r["Preco_Litro_BRL"]   = float(r["Preco_Litro_BRL"])

for r in _manut_raw:
    r["mileage"]        = int(r["mileage"])
    r["cost_BRL"]       = float(r["cost_BRL"])
    r["downtime_hours"] = float(r["downtime_hours"])

# ─── Endpoints de dados simples (sem CSV) ─────────────────────────────────────

def gerar_kpis():
    return {
        "viagens_hoje":     int(12 + random.randint(-1, 2)),
        "passageiros_hoje": int(420 + random.randint(-30, 50)),
        "receita_hoje":     round(18400 + random.uniform(-800, 1200), 2),
        "ocupacao_media":   round(82 + random.uniform(-5, 8), 1),
        "km_rodados_hoje":  int(1840 + random.randint(-100, 200)),
        "alertas_ativos":   3,
        "nps":              round(72 + random.uniform(-3, 5), 1),
        "onibus_em_rota":   5,
    }

def gerar_frota():
    status_options = ["Em rota","Em rota","Em rota","Em rota","Em rota",
                      "Na garagem","Na garagem","Manutenção"]
    # Km total vem do CSV de consumo (soma real)
    km_por_bus = defaultdict(int)
    for r in _fuel_raw:
        km_por_bus[r["Fleet"]] += r["Km_Rodados"]

    result = []
    for i, bus in enumerate(ONIBUS):
        status = status_options[i]
        km_total = km_por_bus.get(bus["id"], 80000 + i * 10000)
        km_proxima_revisao = 10000 - (km_total % 10000)
        combustivel = random.randint(20, 95) if status != "Manutenção" else 30
        rota = ROTAS[i % len(ROTAS)] if status == "Em rota" else None
        result.append({
            **bus,
            "status":            status,
            "km_total":          km_total,
            "km_proxima_revisao": km_proxima_revisao,
            "combustivel":       combustivel,
            "motorista":         MOTORISTAS[i % len(MOTORISTAS)]["nome"] if status == "Em rota" else "—",
            "rota":              rota["nome"] if rota else "—",
            "velocidade":        random.randint(60, 95) if status == "Em rota" else 0,
            "passageiros_bordo": random.randint(28, bus["capacidade"]) if status == "Em rota" else 0,
        })
    return result

def gerar_receita_mensal():
    meses = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]
    base  = [280,260,310,340,380,520,580,610,490,420,380,540]
    return [{"mes": m, "receita": b*1000 + random.randint(-15000,15000),
             "viagens": int(b/15) + random.randint(-5,5)}
            for m,b in zip(meses, base)]

def gerar_ocupacao_por_rota():
    result = []
    for rota in ROTAS:
        result.append({
            "rota":       rota["nome"],
            "ocupacao":   round(65 + random.uniform(0, 30), 1),
            "viagens_mes": random.randint(18, 45),
            "receita_mes": random.randint(40000, 120000),
            "preco_medio": rota["preco"],
        })
    return sorted(result, key=lambda x: x["ocupacao"], reverse=True)

def gerar_alertas_manutencao():
    alertas = [
        {"bus": "BUS-07", "tipo": "Revisão vencida",          "prioridade": "alta",  "dias": -5},
        {"bus": "BUS-04", "tipo": "Troca de óleo em 800km",   "prioridade": "media", "dias": 7},
        {"bus": "BUS-01", "tipo": "Pneu dianteiro desgastado","prioridade": "media", "dias": 10},
    ]
    return alertas

def gerar_stream_frota():
    frota = gerar_frota()
    for bus in frota:
        if bus["status"] == "Em rota":
            bus["velocidade"]  = random.randint(55, 100)
            bus["combustivel"] = max(10, bus["combustivel"] - random.randint(0, 1))
    return frota

# ─── Endpoints CSV — Combustível ─────────────────────────────────────────────

def api_combustivel_mensal_data(ano=2024):
    """Consumo mensal agregado de toda a frota no ano."""
    meses_pt = ["","Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]
    por_mes = defaultdict(lambda: {"litros": 0.0, "custo": 0.0, "km": 0})
    for r in _fuel_raw:
        if r["Year"] == ano:
            m = r["Month"]
            por_mes[m]["litros"] += r["Litros_Consumidos"]
            por_mes[m]["custo"]  += r["Custo_BRL"]
            por_mes[m]["km"]     += r["Km_Rodados"]
    result = []
    for m in range(1, 13):
        d = por_mes[m]
        result.append({
            "mes":    meses_pt[m],
            "litros": round(d["litros"], 1),
            "custo":  round(d["custo"], 2),
            "km":     d["km"],
            "kml":    round(d["km"] / d["litros"], 2) if d["litros"] else 0,
        })
    return result

def api_combustivel_por_onibus_data(ano=2024):
    """Eficiência (km/L) por ônibus no ano — ranking."""
    por_bus = defaultdict(lambda: {"km": 0, "litros": 0.0, "custo": 0.0})
    for r in _fuel_raw:
        if r["Year"] == ano:
            b = r["Fleet"]
            por_bus[b]["km"]     += r["Km_Rodados"]
            por_bus[b]["litros"] += r["Litros_Consumidos"]
            por_bus[b]["custo"]  += r["Custo_BRL"]
    result = []
    for bus in ONIBUS:
        d = por_bus.get(bus["id"], {"km": 0, "litros": 1, "custo": 0})
        result.append({
            "id":        bus["id"],
            "modelo":    bus["modelo"],
            "ano_fab":   bus["ano"],
            "km_total":  d["km"],
            "litros":    round(d["litros"], 1),
            "custo":     round(d["custo"], 2),
            "kml":       round(d["km"] / d["litros"], 2) if d["litros"] else 0,
            "custo_km":  round(d["custo"] / d["km"], 3) if d["km"] else 0,
        })
    return sorted(result, key=lambda x: x["kml"], reverse=True)

def api_preco_litro_data():
    """Evolução do preço médio do diesel por mês/ano."""
    meses_pt = ["","Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]
    por_periodo = defaultdict(list)
    for r in _fuel_raw:
        por_periodo[(r["Year"], r["Month"])].append(r["Preco_Litro_BRL"])
    result = []
    for (ano, mes), precos in sorted(por_periodo.keys()):  # type: ignore
        result.append({
            "periodo": f"{meses_pt[mes]}/{ano}",
            "ano": ano,
            "mes": mes,
            "preco_medio": round(sum(por_periodo[(ano,mes)]) / len(por_periodo[(ano,mes)]), 3),
        })
    return result

# ─── Endpoints CSV — Manutenção ───────────────────────────────────────────────

def api_manutencao_historico_data():
    """Histórico completo de OS — últimas 30 por veículo."""
    por_bus = defaultdict(list)
    for r in _manut_raw:
        por_bus[r["vehicle_id"]].append(r)
    result = []
    for bus_id, registros in sorted(por_bus.items()):
        ultimos = sorted(registros, key=lambda x: x["date"], reverse=True)[:6]
        for r in ultimos:
            result.append({
                "bus":        r["vehicle_id"],
                "placa":      r["placa"],
                "modelo":     r["modelo"],
                "data":       r["date"],
                "km":         r["mileage"],
                "tipo":       r["maintenance_type"],
                "categoria":  r["category"],
                "custo":      r["cost_BRL"],
                "horas":      r["downtime_hours"],
                "tecnico":    r["technician"],
                "pecas":      r["parts_replaced"],
            })
    return result

def api_manutencao_custo_tipo_data():
    """Custo total e contagem por tipo de manutenção."""
    por_tipo = defaultdict(lambda: {"count": 0, "custo": 0.0, "horas": 0.0})
    for r in _manut_raw:
        t = r["maintenance_type"]
        por_tipo[t]["count"] += 1
        por_tipo[t]["custo"] += r["cost_BRL"]
        por_tipo[t]["horas"] += r["downtime_hours"]
    result = []
    for tipo, d in sorted(por_tipo.items(), key=lambda x: x[1]["custo"], reverse=True):
        result.append({
            "tipo":        tipo,
            "count":       d["count"],
            "custo_total": round(d["custo"], 2),
            "custo_medio": round(d["custo"] / d["count"], 2),
            "horas_total": round(d["horas"], 1),
        })
    return result

def api_manutencao_custo_anual_data():
    """Custo de manutenção por ônibus por ano."""
    por_bus_ano = defaultdict(lambda: {"custo": 0.0, "count": 0})
    for r in _manut_raw:
        ano = r["date"][:4]
        por_bus_ano[(r["vehicle_id"], ano)]["custo"] += r["cost_BRL"]
        por_bus_ano[(r["vehicle_id"], ano)]["count"] += 1
    anos = sorted({r["date"][:4] for r in _manut_raw})
    result = []
    for bus in ONIBUS:
        entry = {"id": bus["id"], "modelo": bus["modelo"]}
        for ano in anos:
            d = por_bus_ano.get((bus["id"], ano), {"custo": 0, "count": 0})
            entry[f"custo_{ano}"] = round(d["custo"], 2)
            entry[f"os_{ano}"]    = d["count"]
        result.append(entry)
    return {"anos": anos, "dados": result}

# ─── Rotas Flask ──────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

# Endpoints originais
@app.route("/api/kpis")
def api_kpis():
    return jsonify(gerar_kpis())

@app.route("/api/frota")
def api_frota():
    return jsonify(gerar_frota())

@app.route("/api/receita-mensal")
def api_receita():
    return jsonify(gerar_receita_mensal())

@app.route("/api/ocupacao-rotas")
def api_ocupacao():
    return jsonify(gerar_ocupacao_por_rota())

@app.route("/api/manutencao")
def api_manutencao():
    return jsonify(gerar_alertas_manutencao())

@app.route("/api/motoristas")
def api_motoristas():
    return jsonify(MOTORISTAS)

# Novos endpoints — Combustível (CSV real)
@app.route("/api/combustivel/mensal")
def api_comb_mensal():
    return jsonify(api_combustivel_mensal_data(2024))

@app.route("/api/combustivel/por-onibus")
def api_comb_onibus():
    return jsonify(api_combustivel_por_onibus_data(2024))

@app.route("/api/combustivel/preco-litro")
def api_comb_preco():
    return jsonify(api_preco_litro_data())

# Novos endpoints — Manutenção (CSV real)
@app.route("/api/manutencao/historico")
def api_manut_hist():
    return jsonify(api_manutencao_historico_data())

@app.route("/api/manutencao/custo-tipo")
def api_manut_tipo():
    return jsonify(api_manutencao_custo_tipo_data())

@app.route("/api/manutencao/custo-anual")
def api_manut_anual():
    return jsonify(api_manutencao_custo_anual_data())

# SSE
@app.route("/stream/frota")
def stream_frota():
    def gerar():
        while True:
            dados = gerar_stream_frota()
            yield f"data: {json.dumps(dados)}\n\n"
            time.sleep(6)
    return Response(gerar(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

if __name__ == "__main__":
    app.run(debug=True, port=5001, threaded=True)
